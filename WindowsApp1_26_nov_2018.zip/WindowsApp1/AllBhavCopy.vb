﻿Imports System.Net
Imports System.IO
Imports System.IO.Compression
Imports System.Data.OleDb
Imports System.Data.SqlClient

Imports Excel = Microsoft.Office.Interop.Excel          ' EXCEL APPLICATION.

Public Class AllBhavCopy
	Dim xlApp As Excel.Application
	Dim xlWorkBook As Excel.Workbook
	Dim xlWorkSheet As Excel.Worksheet

	Dim downloadpath = Environment.ExpandEnvironmentVariables("%USERPROFILE%\Downloads") & "\stock_files"

	Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
		Dim totalDays = DateDiff(DateInterval.Day, DateTimePicker1.Value, DateTimePicker2.Value) + 1

		Dim startDate = DateTimePicker1.Value

		Dim currDate = startDate

		For i As Integer = 1 To totalDays

			If Not (currDate.DayOfWeek = DayOfWeek.Saturday Or currDate.DayOfWeek = DayOfWeek.Sunday) Then

				Dim day_val = ""
				If currDate.Day < 10 Then
					day_val = "0" & currDate.Day
				Else
					day_val = currDate.Day
				End If

				Dim file_name_1 = "cm" & day_val & MonthName(currDate.Month, True).ToUpper() & currDate.Year & "bhav.csv.zip"
				Dim file_name_2 = currDate.Year & "/" & MonthName(currDate.Month, True).ToUpper() & "/cm" & day_val & MonthName(currDate.Month, True).ToUpper() & currDate.Year & "bhav.csv.zip"
				Form1.DownloadBhavCopy(file_name_1, file_name_2, currDate)

				Dim dat_name_1 = "MTO_" & day_val & currDate.Month & currDate.Year & ".DAT"
				Form1.DownloadSecurityDat(dat_name_1, dat_name_1, currDate)

				Dim vol_name_1 = "CMVOLT_" & day_val & currDate.Month & currDate.Year & ".CSV"
				Form1.DownloadVolt(vol_name_1, vol_name_1, currDate)

				Dim fobhavcopy_1 = "fo" & day_val & MonthName(currDate.Month, True).ToUpper() & currDate.Year & "bhav.csv.zip"
				Dim fobhavcopy_2 = currDate.Year & "/" & MonthName(currDate.Month, True).ToUpper() & "/fo" & day_val & MonthName(currDate.Month, True).ToUpper() & currDate.Year & "bhav.csv.zip"
				Form1.DownloadFOCopy(fobhavcopy_1, fobhavcopy_2, currDate)


			End If
			currDate = DateAdd("d", 1, currDate)
		Next

		MsgBox("Downloaded All BhavCopy")

	End Sub

	Private Sub AllBhavCopy_Load(sender As Object, e As EventArgs) Handles MyBase.Load
		DateTimePicker2.Value = Today
		DateTimePicker1.Value = DateAdd("d", -365, DateTimePicker2.Value)
	End Sub
End Class